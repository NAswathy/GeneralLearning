---
name: project-brief-doc
description: Create or revise a stakeholder-ready Word (.docx) project brief by consolidating scattered project sources such as meeting notes, research, customer feedback spreadsheets, and existing briefs. Use for requests to draft, refresh, or standardize a project brief with an action-oriented summary, goals, scope, stakeholders, risks, decisions, next steps, open questions, and missing context. Produce a readable metadata table and restrained light-green accents, and preserve uncertainties instead of inventing decisions.
---

# Project Brief Doc

Turn supplied project evidence into a polished, editable Word brief. Adapt to any project; the customer onboarding refresh is an example of the workflow, not permanent project content.

## Workflow

1. **Collect source materials.** Inspect files attached to the conversation or available in its project. Support Markdown/text meeting notes, research documents, `.xlsx` feedback, existing `.docx` briefs, and equivalent readable files. Use connected tools only when a relevant connection is already available and permitted. Do not search unrelated project files or web sources unless the task requires them. If inputs are missing, proceed with clearly labeled gaps where possible.
2. **Build an evidence inventory.** Record source, date if available, major findings, agreements, competing proposals, tentative figures, owners, timelines, and unanswered questions. For spreadsheets, verify columns, record count, denominators, missing values, and any aggregate calculations. Distinguish small-sample statistics from population baselines. Do not make up quantitative targets.
3. **Reconcile carefully.** Label each item `Confirmed agreement`, `Working proposal`, `Recommendation`, or `Open / unconfirmed`. When dates, definitions, ownership, or numbers conflict, present both and identify the decision needed; do not silently choose one. When project source materials identify themselves as examples or sample data, preserve that characterization in appropriate notes or delivery context. Never convert competitor observations into verified external facts without research authorization.
4. **Draft the brief.** Follow [references/brief-outline.md](references/brief-outline.md). Include every requested section. Put a compact metadata table near the title. Write the summary in action-oriented plain language: problem and audience, intended improvements and deliverables, then immediate decisions/actions to unlock execution. Make the distinction between committed scope and suggestions explicit.
5. **Apply Word design.** Create an editable `.docx`, using the installed DOCX capability/skill when available. Use US Letter portrait unless the user requests otherwise. Prefer Aptos/Calibri 10.5–11 pt body, a clear heading hierarchy, readable two-column metadata table (`Field | Detail`), restrained pale-green table header fills and light-green headings/accents (for example `E8F5EA`, `D7EEDC`, and `38805A`), generous whitespace and table padding. Avoid full-width dark fills, zebra striping, and over-decorating. Honor any explicit brand palette or formatting request over these defaults.
6. **Verify and deliver.** Check facts against the inventory, ensure no unsupported claims or resolved-by-assumption decisions, and render every Word page to images for visual inspection. Correct clipping, orphan headings, table wrapping, and crowded pages; rerender after edits. Deliver the final `.docx` link with a brief change summary and a succinct note on major open decisions. Do not send, publish, announce, or schedule any stakeholder action without explicit user authorization.

## Content rules

- Prefer the project's own terminology and segmentation. Attribute numbers to their source and qualify preliminary or inconsistent metrics.
- Keep stakeholders as a role-and-contribution list/table; record accountability as TBD if not decided.
- Write risks as cause/impact with mitigation and dependency where supported; mark newly proposed mitigations as recommendations.
- Separate decisions already made from decisions awaiting approval. Never present proposed pilot dates as confirmed.
- Make next steps concrete, sequence-dependent, and owner-aware; use `Owner: TBD` when ownership is open.
- Include a short `Missing context / validation needed` section even when evidence is limited. Do not fabricate facts to complete headings.
- Treat an existing brief as the editable base for revision; preserve its sections and unrequested details, changing only the specified parts unless material factual errors must be flagged.
