# Project brief structure

Use this order unless user supplies a preferred template or asks for a different order.

1. **Title and metadata**: Project name; document status (`Draft for review` if unresolved); date/as-of date; project sponsor; accountable owner; target customers; phase/time horizon; pilot cohort/date; decision status. Prefer a two-column `Field | Detail` Word table; omit nonsensical rows, mark unknowns `TBD`.
2. **Executive summary** (roughly 100–150 words): What problem is being solved, for whom, what the project will deliver, intended outcomes, and the immediate decisions needed. Use active verbs such as `Simplify`, `Standardize`, `Pilot`, `Measure` when appropriate.
3. **Problem and supporting evidence**: Brief qualitative themes, source-based figures with denominators and limitations, and important research implications. Keep directional baselines distinct from sample statistics.
4. **Goals and measures**: 3–5 goals and proposed or agreed metrics. Mark targets and precise definitions as pending if not established.
5. **Scope**: `In scope` and `Out of scope`, and any dependencies.
6. **Stakeholders and roles**: Function / named representative if provided / role / accountable status. Do not infer final owners from meeting attendance.
7. **Decisions and working agreements**: Completed agreements separate from pending decisions.
8. **Risks and mitigations**: Concise, evidence-grounded items; label suggested mitigations.
9. **Next steps**: Ordered, actionable deliverables with owner/date fields only if sourced or `TBD`.
10. **Open questions**: Questions that block pilot, measurement, or launch.
11. **Missing context / validation needed**: Unavailable data, approvals, capacity, baseline definitions, access, dependencies, and timelines.
12. **Source notes** (optional): Human-readable source filenames/date ranges and caveats.

# Editorial QA checklist

- Can an executive see the required decision/action within the first paragraph?
- Does every metric retain its source population, period, and provisional status?
- Are dates, owners, pilot cohorts, and success criteria *not* invented?
- Are existing agreements separated from proposed recommendations?
- Are the metadata table and headings scannable in Word?
- Did a full DOCX render confirm no truncation, overflow, orphan headings, or awkward whitespace?
